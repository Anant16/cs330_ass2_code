// progtest.cc 
//	Test routines for demonstrating that Nachos can load
//	a user program and execute it.  
//
//	Also, routines for testing the Console hardware device.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "system.h"
#include "console.h"
#include "addrspace.h"
#include "synch.h"
#include "syscall.h"


#define BUFFER_SIZE   1024

//----------------------------------------------------------------------
// ForkNewFunction
// 
//----------------------------------------------------------------------


void
ForkNewFunction (int dummy)
{
   currentThread->Startup();
   DEBUG('t', "returning from startup\n");
   machine->Run();
   DEBUG('t', "returning from machine->Rum()\n");
}


//----------------------------------------------------------------------
// LaunchUserProcess
// 	Run a user program.  Open the executable, load it into
//	memory, and jump to it.
//----------------------------------------------------------------------

void
LaunchUserProcess(char *filename)
{
    OpenFile *executable = fileSystem->Open(filename);
    ProcessAddressSpace *space;

    if (executable == NULL) {
	printf("Unable to open file %s\n", filename);
	return;
    }
    space = new ProcessAddressSpace(executable);    
    currentThread->space = space;

    delete executable;			// close file

    space->InitUserModeCPURegisters();		// set the initial register values
    space->RestoreContextOnSwitch();		// load page table register

    machine->Run();			// jump to the user progam
    ASSERT(FALSE);			// machine->Run never returns;
					// the address space exits
					// by doing the syscall "exit"
}

// Data structures needed for the console test.  Threads making
// I/O requests wait on a Semaphore to delay until the I/O completes.

static Console *console;
static Semaphore *readAvail;
static Semaphore *writeDone;

//----------------------------------------------------------------------
// ConsoleInterruptHandlers
// 	Wake up the thread that requested the I/O.
//----------------------------------------------------------------------

static void ReadAvail(int arg) { readAvail->V(); }
static void WriteDone(int arg) { writeDone->V(); }

//----------------------------------------------------------------------
// ConsoleTest
// 	Test the console by echoing characters typed at the input onto
//	the output.  Stop when the user types a 'q'.
//----------------------------------------------------------------------

void 
ConsoleTest (char *in, char *out)
{
    char ch;

    console = new Console(in, out, ReadAvail, WriteDone, 0);
    readAvail = new Semaphore("read avail", 0);
    writeDone = new Semaphore("write done", 0);
    
    for (;;) {
	readAvail->P();		// wait for character to arrive
	ch = console->GetChar();
	console->PutChar(ch);	// echo it!
	writeDone->P() ;        // wait for write to finish
	if (ch == 'q') return;  // if q, quit
    }
}

//----------------------------------------------------------------------
// LaunchBatchProcess
//  Run user programs.  Open the executables, load it into
//  memory, and jump to it.
//----------------------------------------------------------------------


void
LaunchBatchProcess(char *filename)
{
    //-------------------------- 
    OpenFile* executable;
    NachOSThread* childThread;
    FILE * fp;      
    char name[128], priority[100];
    int priority_int, sched_type;
    int i=0, j=0; 
    //-------------------------- 
    
    fp = fopen(filename, "r");   
    fscanf(fp, "%d", &sched_type);
    
    //for main thread.
    priorityValue[currentThread->GetPID()] = BASE_PRIORITY;
    basePriorityValue[currentThread->GetPID()] = BASE_PRIORITY;
    scheduler->type = sched_type;
    
    //printf("lbp 6, sched_type=%d\n", sched_type);
    bool read_from_string = 0; 
    while( 1 )
    {
        if(read_from_string == 0)
			if(fscanf(fp, "%s", name) == EOF) break;
		else
			sscanf(priority, "%s", name);

		if(fscanf(fp, "%s", priority) == EOF) break;
		if( atoi(priority) == 0 && strcmp(priority, "0"))
		{
		    read_from_string = 1;
			priority_int = 100;	
		}
		else
		{
		    read_from_string = 0;
			sscanf(priority, "%d", &priority_int);
		}
       
        executable = fileSystem->Open(name);

        if (executable == NULL) {
        printf("Unable to open file %s\n", name);
        return;
        }
        childThread = new NachOSThread(name);
        childThread->space = new ProcessAddressSpace(executable);

        basePriorityValue[childThread->GetPID()] = BASE_PRIORITY + priority_int;
        priorityValue[childThread->GetPID()] =  basePriorityValue[childThread->GetPID()];
        
        printf("lbp 7\n");
        delete executable;          // close file

        childThread->space->InitUserModeCPURegisters();      // set the initial register values
        childThread->SaveUserState();
        //childThread->space->RestoreContextOnSwitch();        // load page table register
        childThread->ThreadFork(ForkNewFunction, 0);
        
    }
    //delete executablelist;

    //syscall_wrapper_Exit(0);
    printf("[pid %d]: Exit called. totalTicks: %d\n", currentThread->GetPID(), stats->totalTicks);
       // We do not wait for the children to finish.
       // The children will continue to run.
       // We will worry about this when and if we implement signals.
       exitThreadArray[currentThread->GetPID()] = true;

       // Find out if all threads have called exit
       for (i=0; i<thread_index; i++) {
          if (!exitThreadArray[i]) break;
       }
       currentThread->Exit(i==thread_index, 0);
        
    
}


