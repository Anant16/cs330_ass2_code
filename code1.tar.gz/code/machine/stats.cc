// stats.h 
//	Routines for managing statistics about Nachos performance.
//
// DO NOT CHANGE -- these stats are maintained by the machine emulation.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "utility.h"
#include "stats.h"

//----------------------------------------------------------------------
// Statistics::Statistics
// 	Initialize performance metrics to zero, at system startup.
//----------------------------------------------------------------------

Statistics::Statistics()
{
    totalTicks = idleTicks = systemTicks = userTicks = 0;
    numDiskReads = numDiskWrites = 0;
    numConsoleCharsRead = numConsoleCharsWritten = 0;
    numPageFaults = numPacketsSent = numPacketsRecvd = 0;
    //-----------------------------------------------
    Num_Threads = 0;
    
    Total_CPU_Burst_Time = 0;
    Total_Waiting_Time = 0;
    Total_CPU_Burst_Count = 0;
    Longest_CPU_Burst = 0;
    Shortest_CPU_Burst = 1<<17;
    
    Max_Thread_Comp_Time = 0;
    Min_Thread_Comp_Time = 1<<17;
    Sum_Thread_Comp_Time = 0;
    SumSq_Thread_Comp_Time = 0;
    Sum_Error = 0;
    //-----------------------------------------------
}

//----------------------------------------------------------------------
// Statistics::Print
// 	Print performance metrics, when we've finished everything
//	at system shutdown.
//----------------------------------------------------------------------

void
Statistics::Print()
{
    int Avg_Thread_Comp_Time = Sum_Thread_Comp_Time/(Num_Threads-1);
    long long Var_Thread_Comp_Time = (long long)(SumSq_Thread_Comp_Time)/(Num_Threads-1) - (long long)(Avg_Thread_Comp_Time) * (long long)(Avg_Thread_Comp_Time);
    printf("---------------------------------------------------------------\n");
    printf("------------------------- Statistics --------------------------\n");
    printf("---------------------------------------------------------------\n");
    
    //printf("\tError in Sch-2 = %.4f\n", (1.0*Sum_Error)/Total_CPU_Burst_Time);
    
    printf("\tTotal CPU busy time\t\t\t = %d\n",Total_CPU_Burst_Time);
    printf("\tTotal execution time\t\t\t = %d\n",totalTicks);
    printf("\tCPU utilization\t\t\t\t = %0.3f%\n",(100.0*Total_CPU_Burst_Time)/totalTicks);
    printf("\tMaximum CPU burst length\t\t = %d\n",Longest_CPU_Burst);
    printf("\tMinimum CPU burst length\t\t = %d\n",Shortest_CPU_Burst);
    printf("\tAverage CPU burst length\t\t = %d\n",Total_CPU_Burst_Time/(Total_CPU_Burst_Count-1));
    printf("\tNumber of non-zero CPU bursts observed\t = %d\n",Total_CPU_Burst_Count);
    printf("\tAverage waiting time in the ready queue\t = %d\n",Total_Waiting_Time/(Num_Threads-1));
    printf("\tMaximum thread completion time\t\t = %d\n",Max_Thread_Comp_Time);
    printf("\tMinimum thread completion time\t\t = %d\n",Min_Thread_Comp_Time);
    printf("\tAverage of thread completion time\t = %d\n",Avg_Thread_Comp_Time);
    printf("\tVariance of thread completion time\t = %lld\n",Var_Thread_Comp_Time);
    
    printf("---------------------------------------------------------------\n");
    printf("---------------------------------------------------------------\n");
    printf("---------------------------------------------------------------\n");
    /*printf("Ticks: total %d, idle %d, system %d, user %d\n", totalTicks, 
	idleTicks, systemTicks, userTicks);
    printf("Disk I/O: reads %d, writes %d\n", numDiskReads, numDiskWrites);
    printf("Console I/O: reads %d, writes %d\n", numConsoleCharsRead, 
	numConsoleCharsWritten);
    printf("Paging: faults %d\n", numPageFaults);
    printf("Network I/O: packets received %d, sent %d\n", numPacketsRecvd, 
	numPacketsSent);*/
}
